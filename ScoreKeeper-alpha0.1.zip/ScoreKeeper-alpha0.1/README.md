# ScoreKeeper

[![Gitter](https://badges.gitter.im/SDS-Studios/ScoreKeeper.svg)](https://gitter.im/SDS-Studios/ScoreKeeper?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

This is a android app that is designed for keeping track of a score.

It is being developed for android mobiles and android wair devices.
